package com.shivamshri.tictactoeTTT;

import static com.shivamshri.tictactoeTTT.R.id.I5;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //Dialog nDialog;

    boolean gameActive = true;
    // Player representation
    // 0 - X
    // 1 - O
    int activePlayer = 0;
    int[] gameState = {2, 2, 2, 2, 2, 2, 2, 2, 2};
    //    State meanings:
    //    0 - X
    //    1 - O
    //    2 - Null
    int[][] winPositions = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8},
                            {0, 3, 6}, {1, 4, 7}, {2, 5, 8},
                            {0, 4, 8}, {2, 4, 6}};
    ImageView button1,button2,button3,button4,button5,button6,button7,button8,button9;
    int xCount=0,oCount=0,i=0;
    private TextView scorex,scoreo;
    private Button Restart;
    private EditText input2;
    private EditText input1;
    int counter = 0;

    public void playerTap(View view) {
        ImageView img = (ImageView) view;
        int tappedImage = Integer.parseInt(img.getTag().toString());
        if (!gameActive)
        {
            gameReset(view);
        }
        if (gameState[tappedImage] == 2)
        {
            counter++;
            gameState[tappedImage] = activePlayer;
            img.setTranslationY(-1000f);
            if (activePlayer == 0) {
                img.setImageResource(R.drawable.cross);
                activePlayer = 1;
                input2 = (EditText) findViewById(R.id.Name2);
                TextView status = findViewById(R.id.status);
                status.setText("O - " + input2.getText().toString() + "'s Turn");
            } else {
                img.setImageResource(R.drawable.circle);
                activePlayer = 0;
                TextView status = findViewById(R.id.status);
                input1 = (EditText) findViewById(R.id.Name1);
                status.setText("X - " + input1.getText().toString() + "'s Turn");
            }
            img.animate().translationYBy(1000f).setDuration(300);

        }
        else {
            TextView status = findViewById(R.id.status);
            status.setText("CHOOSE AN EMPTY SPACE !!!");
        }

        Button reset_btn = (Button) findViewById(R.id.reset);
        reset_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent current = getIntent();
                finish();
                startActivity(current);
            }
        });
        int flag =0;

        // Check if any player has won
        for (int[] winPosition : winPositions)
        {

            if (gameState[winPosition[0]] == gameState[winPosition[1]] &&
                    gameState[winPosition[1]] == gameState[winPosition[2]] &&
                    gameState[winPosition[0]] != 2)
            {
                flag = 1;

                // Somebody has won! - Find out who!

                gameActive = false;
                //setContentView(R.layout.popup);
                if (gameState[winPosition[0]] == 0)
                {
                    {
                        input1 = (EditText) findViewById(R.id.Name1);
                        AlertDialog.Builder builder=new AlertDialog.Builder(this);
                        builder.setMessage("Player X - " + input1.getText().toString() + " has WON").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                TextView status = findViewById(R.id.status);
                                status.setText("X's Turn - Tap to play");
                                counter = 0;
                                gameReset(view);
                            }
                        });

                        AlertDialog alertDialog=builder.create();
                        alertDialog.show();
                        xCount++;
                        scorex.setText("Score X :- "+String.valueOf(xCount));

                    }

                    //TextView status = findViewById(R.id.status);
                    //status.setText("X " + input2.getText().toString() + " has WON");

                    //setContentView(R.layout.popupcross);
                    //nDialog = new Dialog(this);
                    //nDialog.setContentView(R.layout.popupcross);
                    //nDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                    //TextView descriptiontv = findViewById(R.id.descriptiontv);
                    //descriptiontv.setText("X " + input1.getText().toString() + " Has WON !!!");

                    //winnerStr = "X has won";

                }

                else
                    {
                        input2 = (EditText) findViewById(R.id.Name2);
                        AlertDialog.Builder builder=new AlertDialog.Builder(this);
                        builder.setMessage("Player O - " + input2.getText().toString() + " has WON").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                TextView status = findViewById(R.id.status);
                                status.setText("X's Turn - Tap to play");
                                counter = 0;
                                gameReset(view);
                            }
                        });

                        AlertDialog alertDialog=builder.create();
                        alertDialog.show();
                        oCount++;
                        scoreo.setText("Score O :- "+String.valueOf(oCount));


                    }
                    //TextView status = findViewById(R.id.status);
                    //status.setText("O " + input1.getText().toString() + " has WON");

                    //setContentView(R.layout.popup);
                    //nDialog = new Dialog(this);
                    //nDialog.setContentView(R.layout.popup);
                    //nDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                    //TextView descriptiontv = findViewById(R.id.descriptiontv);
                    //descriptiontv.setText("O " + input2.getText().toString() + " Has WON !!!");

                    //winnerStr = "O has won";
            }

            // Update the status bar for winner announcement
            //TextView status = findViewById(R.id.status);
            //status.setText(winnerStr);
        }
        if (counter == 9 && flag == 0)
        {
            AlertDialog.Builder builder=new AlertDialog.Builder(this);
            builder.setMessage("No One Wins - MATCH DRAW").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    TextView status = findViewById(R.id.status);
                    status.setText("X's Turn - Tap to play");
                    gameReset(view);
                    counter = 0;
                }
            });

            AlertDialog alertDialog=builder.create();
            alertDialog.show();
        }

    }

    public void gameReset(View view)
    {
        gameActive = true;
        activePlayer = 0;
        counter = 0;
        for(int i=0; i<gameState.length; i++)
        {
            gameState[i] = 2;
        }
        ((ImageView)findViewById(R.id.imageView0)).setImageResource(0);
        ((ImageView)findViewById(R.id.imageView1)).setImageResource(0);
        ((ImageView)findViewById(R.id.imageView2)).setImageResource(0);
        ((ImageView)findViewById(R.id.imageView3)).setImageResource(0);
        ((ImageView)findViewById(R.id.imageView4)).setImageResource(0);
        ((ImageView)findViewById(R.id.imageView5)).setImageResource(0);
        ((ImageView)findViewById(R.id.imageView6)).setImageResource(0);
        ((ImageView)findViewById(R.id.imageView7)).setImageResource(0);
        ((ImageView)findViewById(R.id.imageView8)).setImageResource(0);
        TextView status = findViewById(R.id.status);
        status.setText("X's Turn - Tap to play");
        //xCount=0;
        //oCount=0;
        //scorex.setText("Score X :- "+String.valueOf(xCount));
        //scoreo.setText("Score Y :- "+String.valueOf(oCount));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        button1=findViewById(R.id.imageView0);
        button2=findViewById(R.id.imageView1);
        button3=findViewById(R.id.imageView2);
        button4=findViewById(R.id.imageView3);
        button5=findViewById(R.id.imageView4);
        button6=findViewById(R.id.imageView5);
        button7=findViewById(R.id.imageView6);
        button8=findViewById(R.id.imageView7);
        button9=findViewById(R.id.imageView8);

        scorex = findViewById(R.id.ScoreX);
        scoreo = findViewById(R.id.ScoreY);

        Restart=findViewById(R.id.restart);
        Restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                gameActive = true;
                activePlayer = 0;
                counter = 0;
                for(int i=0; i<gameState.length; i++)
                {
                    gameState[i] = 2;
                }
                ((ImageView)findViewById(R.id.imageView0)).setImageResource(0);
                ((ImageView)findViewById(R.id.imageView1)).setImageResource(0);
                ((ImageView)findViewById(R.id.imageView2)).setImageResource(0);
                ((ImageView)findViewById(R.id.imageView3)).setImageResource(0);
                ((ImageView)findViewById(R.id.imageView4)).setImageResource(0);
                ((ImageView)findViewById(R.id.imageView5)).setImageResource(0);
                ((ImageView)findViewById(R.id.imageView6)).setImageResource(0);
                ((ImageView)findViewById(R.id.imageView7)).setImageResource(0);
                ((ImageView)findViewById(R.id.imageView8)).setImageResource(0);
                TextView status = findViewById(R.id.status);
                status.setText("X's Turn - Tap to play");

                //xCount=0;
                //oCount=0;
                scorex.setText("Score X :- "+String.valueOf(xCount));
                scoreo.setText("Score O :- "+String.valueOf(oCount));
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_view,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.I1:
            {
                Uri uri = Uri.parse("https://play.google.com/store/apps/developer?id=Saksham+Shri&hl=en&gl=IN");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                startActivity(intent);
                break;
            }
            case R.id.I2:
            {
                Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.shivamshri.tictactoeTTT");
                Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                startActivity(intent);
                break;
            }
            case R.id.I3:
            {
                alertDialog();
                break;
            }
            case I5:
            {
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto","developer.saksham07@gmail.com",null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT,"Feedback");
                emailIntent.putExtra(Intent.EXTRA_TEXT,"Body");
                startActivity(Intent.createChooser(emailIntent,"Send Email....."));
                break;
            }

            case R.id.I4:
            {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,"See, I found An Amazing App!\n" + "https://play.google.com/store/apps/details?id=com.shivam.tictactoe");
                sendIntent.setType("text/plain");
                Intent shareIntent = Intent.createChooser(sendIntent,null);
                startActivity(shareIntent);
                break;
            }


        }

        return true;
    }
    private void alertDialog() {
        AlertDialog.Builder dialog=new AlertDialog.Builder(this);
        dialog.setMessage("Developed By - Saksham Shri");
        dialog.setPositiveButton("Visit Instagram",
                new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Uri uri = Uri.parse("https://www.instagram.com/just_status__/?utm_medium=copy_link");
                        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                        startActivity(intent);
                    }
                });
        AlertDialog alertDialog=dialog.create();
        alertDialog.show();
    }
}
